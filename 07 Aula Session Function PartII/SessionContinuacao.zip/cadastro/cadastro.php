<?php
	//Verificando session
    require('../login/verificador.php');
    VerificarLogin();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Listinha</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container mt-4">

	<!-- Substituindo jumbotron -->
	<div class="p-4 mb-4 bg-light rounded">
		<h1>Cadastro de Produtos</h1>
		<p>Produtos fofos!</p>
		<p>Bem-vindo: <?php echo $_SESSION['login'] ?></p>
	</div>

	<!-- Navegação -->
	<ul class="nav nav-tabs mb-3">
		<li class="nav-item">
			<a class="nav-link active" href="../Cadastro/cadastro.php">
				Cadastrar Produto
			</a> 
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">
				Lista Produtos
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">
				Usuários
			</a>
		</li>
	</ul>


	<!-- Formulário -->
	<form action="doCadastro.php" method="POST" 
		enctype="multipart/form-data">
		<!-- Nome -->
		<div class="mb-3">
			<label class="form-label">Nome:</label>		
			<input type="text" name="nome" class="form-control">
		</div>
		<!-- Nome -->

		<!-- Descrição -->
		<div class="mb-3">
			<label class="form-label">Descrição:</label>		
			<input type="text" name="descricao" class="form-control">
		</div>
		<!-- Descrição -->

		<!-- Área -->
		<div class="mb-3">
			<label class="form-label">Descrição:</label>		
			<select class="form-select" name="area">
				<option>...</option>
				<option value="1">Eletrodoméstico</option>
				<option value="2">Eletrônicos</option>
				<option value="3">Manutenção</option>
			</select>
		</div>
		<!-- Área -->

		<!-- Preço -->
		<div class="mb-3">
			<label class="form-label">Preço:</label>		
			<input type="text" name="preco" class="form-control">
		</div>
		<!-- Preço -->

		<!-- Moeda -->
		<div class="mb-3">
			<label class="form-label">Preço:</label>		
			<select class="form-select" name="moeda">
				<option>...</option>
				<option value="R$">R$ - Real</option>
				<option value="US$">US$ - Dólar</option>
			</select>
		</div>
		<!-- Moeda -->

		<!-- País -->
		<div class="mb-3">
			<label class="form-label">País:</label>		
			<input type="text" name="pais" class="form-control">
		</div>
		<!-- País -->

		<!-- Imagem -->
		<div class="mb-3">
			<label class="form-label">Imagem:</label>		
			<input type="file" name="foto" class="form-control">
		</div>
		<!-- Imagem -->		

		<!-- Botões -->
			<div class="d-flex gap-2">
				<button type="submit" class= "btn btn-primary">Cadastrar</button>
				<button type="submit" class="btn btn-primary" 	>Limpar</button>
			</div>
		<!-- Botões -->
	</form>




	

</div>

</body>
</html>