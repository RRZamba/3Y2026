<?php
	include ('../conexao/conexao.php');

	$login = $_POST['login'];
	$senha = $_POST['senha'];

	$sql = "SELECT * FROM login WHERE login = '$login' AND senha = '$senha'";

	$resultado = mysqli_query($con,$sql);




?>
